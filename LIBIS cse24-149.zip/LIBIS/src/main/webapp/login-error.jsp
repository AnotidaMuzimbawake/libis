<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login failed</title>
</head>
<body style="font-family: Arial, sans-serif; margin-top: 80px; text-align: center;">
<h2>Login failed</h2>
<p style="color:#b00020;">Wrong username or password.</p>
<a href="${pageContext.request.contextPath}/login.jsp">Try again</a>
</body>
</html>