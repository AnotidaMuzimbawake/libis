<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS - Confirm delete</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
        .container { max-width: 600px; margin: auto; background-color: white; padding: 30px; border-radius: 8px; }
        .warn { color: #b00020; }
        button { padding: 10px 18px; cursor: pointer; }
    </style>
</head>
<body>
<div class="container">

    <h1>Delete member?</h1>

    <p>
        You are about to delete
        <strong><c:out value="${member.memberNumber}"/> (<c:out value="${member.fullName}"/>)</strong>.
    </p>
    <p class="warn">
        This also deletes this member's whole borrowing history. Any book they still hold becomes available again.
    </p>

    <form action="${pageContext.request.contextPath}/librarian/members" method="post">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="memberId" value="<c:out value='${member.memberId}'/>">
        <button type="submit">Yes, delete this member</button>
        <a href="${pageContext.request.contextPath}/librarian/members">Cancel</a>
    </form>

</div>
</body>
</html>