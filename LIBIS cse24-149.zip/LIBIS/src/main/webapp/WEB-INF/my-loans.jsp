<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${param.lang == 'en' or param.lang == 'tn'}">
    <fmt:setLocale value="${param.lang}" scope="session"/>
</c:if>
<fmt:setBundle basename="messages"/>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
        .container { max-width: 1000px; margin: auto; background-color: white; padding: 30px; border-radius: 8px; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0 30px 0; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #333; color: white; }
        .error { color: #b00020; }
        .info { color: #1b6e2d; }
    </style>
</head>
<body>
<div class="container">

    <div class="top-bar">
        <h1><fmt:message key="loans.heading"/></h1>
        <div>
            <a href="${pageContext.request.contextPath}/catalogue"><fmt:message key="nav.catalogue"/></a> |
            <a href="${pageContext.request.contextPath}/logout"><fmt:message key="nav.logout"/></a>
        </div>
    </div>

    <p>
        <fmt:message key="lang.label"/>:
        <a href="${pageContext.request.contextPath}/my-loans?lang=en"><fmt:message key="lang.en"/></a> |
        <a href="${pageContext.request.contextPath}/my-loans?lang=tn"><fmt:message key="lang.tn"/></a>
    </p>

    <c:if test="${not empty sessionScope.flashError}">
        <p class="error"><fmt:message key="${sessionScope.flashError}"/></p>
        <c:remove var="flashError" scope="session"/>
    </c:if>
    <c:if test="${not empty sessionScope.flashInfo}">
        <p class="info"><fmt:message key="${sessionScope.flashInfo}"/></p>
        <c:remove var="flashInfo" scope="session"/>
    </c:if>

    <h2><fmt:message key="loans.current"/></h2>
    <c:choose>
        <c:when test="${empty openLoans}">
            <p><fmt:message key="loans.none"/></p>
        </c:when>
        <c:otherwise>
            <table>
                <thead>
                <tr>
                    <th><fmt:message key="loans.col.title"/></th>
                    <th><fmt:message key="loans.col.borrowed"/></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <c:forEach var="loan" items="${openLoans}">
                    <tr>
                        <td><c:out value="${loan.bookTitle}"/></td>
                        <td><c:out value="${loan.borrowedOn}"/></td>
                        <td>
                            <form action="${pageContext.request.contextPath}/return" method="post">
                                <input type="hidden" name="bookId" value="<c:out value='${loan.bookId}'/>">
                                <button type="submit"><fmt:message key="action.return"/></button>
                            </form>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

    <h2><fmt:message key="loans.history"/></h2>
    <c:choose>
        <c:when test="${empty history}">
            <p><fmt:message key="loans.nohistory"/></p>
        </c:when>
        <c:otherwise>
            <table>
                <thead>
                <tr>
                    <th><fmt:message key="loans.col.title"/></th>
                    <th><fmt:message key="loans.col.borrowed"/></th>
                    <th><fmt:message key="loans.col.returned"/></th>
                </tr>
                </thead>
                <tbody>
                <c:forEach var="loan" items="${history}">
                    <tr>
                        <td><c:out value="${loan.bookTitle}"/></td>
                        <td><c:out value="${loan.borrowedOn}"/></td>
                        <td><c:out value="${loan.returnedOn}"/></td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

</div>
</body>
</html>