<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS - Book form</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
        .container { max-width: 600px; margin: auto; background-color: white; padding: 30px; border-radius: 8px; }
        label { display: block; margin-top: 12px; font-size: 14px; }
        input, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 18px; padding: 10px 18px; cursor: pointer; }
        .error { color: #b00020; }
    </style>
</head>
<body>
<div class="container">

    <h1><c:choose>
        <c:when test="${formAction == 'update'}">Edit book</c:when>
        <c:otherwise>Add book</c:otherwise>
    </c:choose></h1>

    <c:if test="${not empty errors}">
        <ul class="error">
            <c:forEach var="e" items="${errors}">
                <li><c:out value="${e}"/></li>
            </c:forEach>
        </ul>
    </c:if>

    <form action="${pageContext.request.contextPath}/librarian/books" method="post">
        <input type="hidden" name="action" value="<c:out value='${formAction}'/>">
        <input type="hidden" name="bookId" value="<c:out value='${book.bookId}'/>">

        <label for="isbn">ISBN</label>
        <input type="text" id="isbn" name="isbn" value="<c:out value='${book.isbn}'/>">

        <label for="title">Title</label>
        <input type="text" id="title" name="title" value="<c:out value='${book.title}'/>">

        <label for="author">Author</label>
        <input type="text" id="author" name="author" value="<c:out value='${book.author}'/>">

        <label for="genre">Genre</label>
        <input type="text" id="genre" name="genre" value="<c:out value='${book.genre}'/>">

        <label for="publishedYear">Published year</label>
        <input type="text" id="publishedYear" name="publishedYear" value="<c:out value='${yearText}'/>">

        <label for="synopsis">Synopsis</label>
        <textarea id="synopsis" name="synopsis" rows="4"><c:out value="${book.synopsis}"/></textarea>

        <button type="submit">Save</button>
        <a href="${pageContext.request.contextPath}/librarian/books">Cancel</a>
    </form>

</div>
</body>
</html>