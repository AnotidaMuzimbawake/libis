<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS - Member form</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
        .container { max-width: 600px; margin: auto; background-color: white; padding: 30px; border-radius: 8px; }
        label { display: block; margin-top: 12px; font-size: 14px; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 18px; padding: 10px 18px; cursor: pointer; }
        .error { color: #b00020; }
    </style>
</head>
<body>
<div class="container">

    <h1><c:choose>
        <c:when test="${formAction == 'update'}">Edit member</c:when>
        <c:otherwise>Add member</c:otherwise>
    </c:choose></h1>

    <c:if test="${not empty errors}">
        <ul class="error">
            <c:forEach var="e" items="${errors}">
                <li><c:out value="${e}"/></li>
            </c:forEach>
        </ul>
    </c:if>

    <form action="${pageContext.request.contextPath}/librarian/members" method="post">
        <input type="hidden" name="action" value="<c:out value='${formAction}'/>">
        <input type="hidden" name="memberId" value="<c:out value='${member.memberId}'/>">

        <label for="memberNumber">Member number</label>
        <input type="text" id="memberNumber" name="memberNumber" value="<c:out value='${member.memberNumber}'/>">

        <label for="fullName">Full name</label>
        <input type="text" id="fullName" name="fullName" value="<c:out value='${member.fullName}'/>">

        <label for="email">Email</label>
        <input type="text" id="email" name="email" value="<c:out value='${member.email}'/>">

        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<c:out value='${member.username}'/>">

        <label for="password">
            Password
            <c:if test="${formAction == 'update'}">(leave blank to keep the current password)</c:if>
        </label>
        <input type="password" id="password" name="password" autocomplete="new-password">

        <label for="role">Role</label>
        <select id="role" name="role">
            <option value="member" ${member.role == 'member' ? 'selected' : ''}>member</option>
            <option value="librarian" ${member.role == 'librarian' ? 'selected' : ''}>librarian</option>
        </select>

        <button type="submit">Save</button>
        <a href="${pageContext.request.contextPath}/librarian/members">Cancel</a>
    </form>

</div>
</body>
</html>