<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS - Members</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
        .container { max-width: 1100px; margin: auto; background-color: white; padding: 30px; border-radius: 8px; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #333; color: white; }
        .error { color: #b00020; }
        .info { color: #1b6e2d; }
    </style>
</head>
<body>
<div class="container">

    <div class="top-bar">
        <h1>Members</h1>
        <div>
            <a href="${pageContext.request.contextPath}/librarian/books">Books</a> |
            <a href="${pageContext.request.contextPath}/catalogue">Catalogue</a> |
            <a href="${pageContext.request.contextPath}/logout">Log out</a>
        </div>
    </div>

    <c:if test="${not empty sessionScope.adminError}">
        <p class="error"><c:out value="${sessionScope.adminError}"/></p>
        <c:remove var="adminError" scope="session"/>
    </c:if>
    <c:if test="${not empty sessionScope.adminInfo}">
        <p class="info"><c:out value="${sessionScope.adminInfo}"/></p>
        <c:remove var="adminInfo" scope="session"/>
    </c:if>

    <form action="${pageContext.request.contextPath}/librarian/members" method="get">
        <label for="q">Search by name or member number:</label>
        <input type="text" id="q" name="q" value="<c:out value='${searchTerm}'/>">
        <button type="submit">Search</button>
        <a href="${pageContext.request.contextPath}/librarian/members">Clear</a>
        &nbsp;&nbsp;
        <a href="${pageContext.request.contextPath}/librarian/members?action=new">+ Add member</a>
    </form>

    <c:choose>
        <c:when test="${empty members}">
            <p>No members found.</p>
        </c:when>
        <c:otherwise>
            <table>
                <thead>
                <tr>
                    <th>Member no.</th><th>Full name</th><th>Email</th><th>Username</th><th>Role</th><th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach var="m" items="${members}">
                    <tr>
                        <td><c:out value="${m.memberNumber}"/></td>
                        <td><c:out value="${m.fullName}"/></td>
                        <td><c:out value="${m.email}"/></td>
                        <td><c:out value="${m.username}"/></td>
                        <td><c:out value="${m.role}"/></td>
                        <td>
                            <a href="${pageContext.request.contextPath}/librarian/members?action=edit&id=${m.memberId}">Edit</a> |
                            <a href="${pageContext.request.contextPath}/librarian/members?action=confirm&id=${m.memberId}">Delete</a>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

</div>
</body>
</html>