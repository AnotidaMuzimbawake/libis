<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${param.lang == 'en' or param.lang == 'tn'}">
    <fmt:setLocale value="${param.lang}" scope="session"/>
</c:if>
<fmt:setBundle basename="messages"/>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LIBIS</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 {
            color: #333;
        }

        .search-form {
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="top-bar">
        <h1>
            <fmt:message key="catalogue.welcome"/> <c:out value="${pageContext.request.remoteUser}"/>
        </h1>
        <div>
            <c:if test="${pageContext.request.isUserInRole('librarian')}">
                <a href="${pageContext.request.contextPath}/librarian/members"><fmt:message key="nav.members"/></a> |
                <a href="${pageContext.request.contextPath}/librarian/books"><fmt:message key="nav.books"/></a> |
            </c:if>
            <c:if test="${pageContext.request.isUserInRole('member')}">
                <a href="${pageContext.request.contextPath}/my-loans"><fmt:message key="nav.myloans"/></a> |
            </c:if>
            <a href="${pageContext.request.contextPath}/logout"><fmt:message key="nav.logout"/></a>
        </div>
    </div>

    <p>
        <fmt:message key="lang.label"/>:
        <a href="${pageContext.request.contextPath}/catalogue?lang=en"><fmt:message key="lang.en"/></a> |
        <a href="${pageContext.request.contextPath}/catalogue?lang=tn"><fmt:message key="lang.tn"/></a>
    </p>

    <p><fmt:message key="catalogue.intro"/></p>

    <c:if test="${not empty sessionScope.flashError}">
        <p style="color:#b00020;"><fmt:message key="${sessionScope.flashError}"/></p>
        <c:remove var="flashError" scope="session"/>
    </c:if>
    <c:if test="${not empty sessionScope.flashInfo}">
        <p style="color:#1b6e2d;"><fmt:message key="${sessionScope.flashInfo}"/></p>
        <c:remove var="flashInfo" scope="session"/>
    </c:if>
    <c:if test="${not empty error}">
        <p style="color:#b00020;"><c:out value="${error}"/></p>
    </c:if>

    <form class="search-form" action="${pageContext.request.contextPath}/catalogue" method="get">
        <label for="q"><fmt:message key="catalogue.search.label"/></label>
        <input type="text" id="q" name="q" value="<c:out value='${searchTerm}'/>">
        <button type="submit"><fmt:message key="catalogue.search.button"/></button>
        <a href="${pageContext.request.contextPath}/catalogue"><fmt:message key="catalogue.clear"/></a>
    </form>

    <c:choose>
        <c:when test="${empty books}">
            <p><fmt:message key="catalogue.empty"/></p>
        </c:when>
        <c:otherwise>
            <table>
                <thead>
                <tr>
                    <th><fmt:message key="catalogue.col.id"/></th>
                    <th><fmt:message key="catalogue.col.title"/></th>
                    <th><fmt:message key="catalogue.col.author"/></th>
                    <th><fmt:message key="catalogue.col.genre"/></th>
                    <th><fmt:message key="catalogue.col.available"/></th>
                    <th><fmt:message key="catalogue.col.actions"/></th>
                </tr>
                </thead>

                <tbody>

                <c:forEach var="book" items="${books}">
                    <tr>
                        <td><c:out value="${book.bookId}"/></td>
                        <td><c:out value="${book.title}"/></td>
                        <td><c:out value="${book.author}"/></td>
                        <td><c:out value="${book.genre}"/></td>
                        <td>
                            <c:choose>
                                <c:when test="${book.available}"><fmt:message key="common.yes"/></c:when>
                                <c:otherwise><fmt:message key="common.no"/></c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <c:if test="${pageContext.request.isUserInRole('member')}">
                                <form action="${pageContext.request.contextPath}/borrow" method="post" style="display:inline;">
                                    <input type="hidden" name="bookId" value="<c:out value='${book.bookId}'/>">
                                    <button type="submit"><fmt:message key="action.borrow"/></button>
                                </form>
                                <button type="button" disabled><fmt:message key="action.reserve"/></button>
                            </c:if>
                        </td>
                    </tr>
                </c:forEach>

                </tbody>
            </table>
        </c:otherwise>
    </c:choose>

</div>

</body>
</html>