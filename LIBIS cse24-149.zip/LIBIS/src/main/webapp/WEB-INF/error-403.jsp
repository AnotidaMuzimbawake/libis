<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access denied</title>
</head>
<body style="font-family: Arial, sans-serif; margin-top: 80px; text-align: center;">
<h2>403 – Access denied</h2>
<p>Your role does not allow you to open this page.</p>
<a href="${pageContext.request.contextPath}/catalogue">Back to the catalogue</a>
</body>
</html>