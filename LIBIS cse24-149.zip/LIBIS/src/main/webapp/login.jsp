<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            margin-top: 80px;
        }

        .login-box {
            width: 280px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 4px;
            box-sizing: border-box;
        }

        button {
            margin-top: 16px;
            padding: 10px;
            width: 100%;
            cursor: pointer;
        }

        .error {
            color: #b00020;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>LIBIS Login</h2>

    <form action="j_security_check" method="post">

        <label for="username">Email</label>
        <input type="text" id="username" name="j_username" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="j_password" required>

        <button type="submit">Submit</button>

    </form>
</div>

</body>
</html>
