package com.example.libis.dao;

import com.example.libis.config.DatabaseConfig;
import com.example.libis.exception.DataAccessException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


final class Jdbc {

    private static final Logger LOG = Logger.getLogger(Jdbc.class.getName());

    interface Binder {
        void bind(PreparedStatement ps) throws SQLException;
    }

    interface RowMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }

    static final Binder NONE = ps -> { };

    private Jdbc() {
    }

    static <T> List<T> queryList(String sql, Binder binder, RowMapper<T> mapper) {
        List<T> rows = new ArrayList<>();
        try (Connection con = DatabaseConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            binder.bind(ps);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(mapper.map(rs));
                }
            }
        } catch (SQLException e) {
            throw translate(sql, e);
        }
        return rows;
    }

    static <T> T queryOne(String sql, Binder binder, RowMapper<T> mapper) {
        List<T> rows = queryList(sql, binder, mapper);
        return rows.isEmpty() ? null : rows.get(0);
    }

    static int count(String sql, Binder binder) {
        Integer n = queryOne(sql, binder, rs -> rs.getInt(1));
        return n == null ? 0 : n;
    }

    static int update(String sql, Binder binder) {
        try (Connection con = DatabaseConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            binder.bind(ps);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw translate(sql, e);
        }
    }

    private static DataAccessException translate(String sql, SQLException e) {
        LOG.log(Level.SEVERE, "SQL failed: " + sql, e);
        return new DataAccessException("A database error occurred. Please try again.", e);
    }
}