package com.example.libis.controller;

import com.example.libis.dao.MemberDao;
import com.example.libis.dao.MemberDaoImpl;
import com.example.libis.exception.DataAccessException;
import com.example.libis.exception.LoanException;
import com.example.libis.model.Member;
import com.example.libis.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "returnController", value = "/return")
public class ReturnController extends HttpServlet {

    private final LoanService loanService = new LoanService();
    private final MemberDao memberDao = new MemberDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/my-loans");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        try {
            Member member = memberDao.findByUsername(request.getRemoteUser());
            int bookId = Integer.parseInt(request.getParameter("bookId"));
            loanService.giveBack(member.getMemberId(), bookId);
            session.setAttribute("flashInfo", "msg.returned");
        } catch (LoanException e) {
            session.setAttribute("flashError", e.getMessageKey());
        } catch (NumberFormatException e) {
            session.setAttribute("flashError", "error.book.notfound");
        } catch (DataAccessException e) {
            log("Return failed", e);
            session.setAttribute("flashError", "error.database");
        }
        response.sendRedirect(request.getContextPath() + "/my-loans");
    }
}