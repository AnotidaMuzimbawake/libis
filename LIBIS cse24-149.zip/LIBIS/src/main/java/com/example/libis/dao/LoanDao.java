package com.example.libis.dao;

import com.example.libis.model.Loan;

import java.time.LocalDate;
import java.util.List;

public interface LoanDao {
    void create(int memberId, int bookId, LocalDate borrowedOn);

    // Sets returned_on on the member's open loan of that book. Returns false if there was none.
    boolean markReturned(int memberId, int bookId, LocalDate returnedOn);

    int countOpenByMember(int memberId);
    List<Loan> findOpenByMember(int memberId);
    List<Loan> findHistoryByMember(int memberId);
    boolean hasOpenLoan(int bookId);
}