package com.example.libis.dao;

import com.example.libis.config.DatabaseConfig;
import com.example.libis.exception.DataAccessException;
import com.example.libis.model.Book;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDaoImpl implements BookDao {


    private static final String BASE_SELECT =
            "SELECT b.book_id, b.isbn, b.title, b.author, b.genre, b.synopsis, "
                    + "b.published_year, (l.loan_id IS NULL) AS available "
                    + "FROM books b "
                    + "LEFT JOIN loans l ON l.book_id = b.book_id AND l.returned_on IS NULL ";

    @Override
    public List<Book> findAll() {
        return Jdbc.queryList(BASE_SELECT + "ORDER BY b.book_id", Jdbc.NONE, BookDaoImpl::map);
    }

    @Override
    public Book findById(int bookId) {
        return Jdbc.queryOne(BASE_SELECT + "WHERE b.book_id = ?",
                ps -> ps.setInt(1, bookId), BookDaoImpl::map);
    }


    @Override
    public List<Book> search(String term) {
        String sql = BASE_SELECT + "WHERE b.title LIKE ? OR b.author LIKE ? ORDER BY b.book_id";
        List<Book> books = new ArrayList<>();
        try (Connection con = DatabaseConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String pattern = "%" + term + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    books.add(map(rs));
                }
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not search books", e);
        }
        return books;
    }

    @Override
    public Book findByIsbn(String isbn) {
        return Jdbc.queryOne(BASE_SELECT + "WHERE b.isbn = ?",
                ps -> ps.setString(1, isbn), BookDaoImpl::map);
    }

    @Override
    public void create(Book book) {
        Jdbc.update("INSERT INTO books (isbn, title, author, genre, synopsis, published_year) "
                        + "VALUES (?, ?, ?, ?, ?, ?)",
                ps -> {
                    ps.setString(1, book.getIsbn());
                    ps.setString(2, book.getTitle());
                    ps.setString(3, book.getAuthor());
                    ps.setString(4, book.getGenre());
                    ps.setString(5, book.getSynopsis());
                    ps.setInt(6, book.getPublishedYear());
                });
    }

    @Override
    public void update(Book book) {
        Jdbc.update("UPDATE books SET isbn = ?, title = ?, author = ?, genre = ?, "
                        + "synopsis = ?, published_year = ? WHERE book_id = ?",
                ps -> {
                    ps.setString(1, book.getIsbn());
                    ps.setString(2, book.getTitle());
                    ps.setString(3, book.getAuthor());
                    ps.setString(4, book.getGenre());
                    ps.setString(5, book.getSynopsis());
                    ps.setInt(6, book.getPublishedYear());
                    ps.setInt(7, book.getBookId());
                });
    }


    @Override
    public void delete(int bookId) {
        Jdbc.update("DELETE FROM books WHERE book_id = ?", ps -> ps.setInt(1, bookId));
    }

    private static Book map(ResultSet rs) throws SQLException {
        Book b = new Book();
        b.setBookId(rs.getInt("book_id"));
        b.setIsbn(rs.getString("isbn"));
        b.setTitle(rs.getString("title"));
        b.setAuthor(rs.getString("author"));
        b.setGenre(rs.getString("genre"));
        b.setSynopsis(rs.getString("synopsis"));
        b.setPublishedYear(rs.getInt("published_year"));
        b.setAvailable(rs.getBoolean("available"));
        return b;
    }
}