package com.example.libis.dao;

import com.example.libis.model.Member;

import java.util.List;

public interface MemberDao {
    List<Member> findAll();
    Member findById(int memberId);
    Member findByUsername(String username);
    List<Member> search(String term);
    Member findByMemberNumber(String memberNumber);
    Member findByEmail(String email);
    void create(Member member);
    void update(Member member);
    void delete(int memberId);
}
