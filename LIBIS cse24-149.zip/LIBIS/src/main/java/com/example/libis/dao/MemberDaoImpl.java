package com.example.libis.dao;

import com.example.libis.model.Member;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class MemberDaoImpl implements MemberDao {

    private static final String BASE =
            "SELECT member_id, member_number, full_name, email, username, password, role FROM members ";

    @Override
    public List<Member> findAll() {
        return Jdbc.queryList(BASE + "ORDER BY member_id", Jdbc.NONE, MemberDaoImpl::map);
    }

    @Override
    public Member findById(int memberId) {
        return Jdbc.queryOne(BASE + "WHERE member_id = ?",
                ps -> ps.setInt(1, memberId), MemberDaoImpl::map);
    }

    @Override
    public Member findByUsername(String username) {
        return Jdbc.queryOne(BASE + "WHERE username = ?",
                ps -> ps.setString(1, username), MemberDaoImpl::map);
    }


    @Override
    public List<Member> search(String term) {
        String pattern = "%" + term + "%";
        return Jdbc.queryList(BASE + "WHERE full_name LIKE ? OR member_number LIKE ? ORDER BY member_id",
                ps -> {
                    ps.setString(1, pattern);
                    ps.setString(2, pattern);
                }, MemberDaoImpl::map);
    }

    @Override
    public Member findByMemberNumber(String memberNumber) {
        return Jdbc.queryOne(BASE + "WHERE member_number = ?",
                ps -> ps.setString(1, memberNumber), MemberDaoImpl::map);
    }

    @Override
    public Member findByEmail(String email) {
        return Jdbc.queryOne(BASE + "WHERE email = ?",
                ps -> ps.setString(1, email), MemberDaoImpl::map);
    }

    @Override
    public void create(Member m) {
        Jdbc.update("INSERT INTO members (member_number, full_name, email, username, password, role) "
                        + "VALUES (?, ?, ?, ?, ?, ?)",
                ps -> {
                    ps.setString(1, m.getMemberNumber());
                    ps.setString(2, m.getFullName());
                    ps.setString(3, m.getEmail());
                    ps.setString(4, m.getUsername());
                    ps.setString(5, m.getPassword());
                    ps.setString(6, m.getRole());
                });
    }


    @Override
    public void update(Member m) {
        Jdbc.update("UPDATE members SET member_number = ?, full_name = ?, email = ?, "
                        + "username = ?, password = ?, role = ? WHERE member_id = ?",
                ps -> {
                    ps.setString(1, m.getMemberNumber());
                    ps.setString(2, m.getFullName());
                    ps.setString(3, m.getEmail());
                    ps.setString(4, m.getUsername());
                    ps.setString(5, m.getPassword());
                    ps.setString(6, m.getRole());
                    ps.setInt(7, m.getMemberId());
                });
    }

    @Override
    public void delete(int memberId) {
        Jdbc.update("DELETE FROM members WHERE member_id = ?", ps -> ps.setInt(1, memberId));
    }

    private static Member map(ResultSet rs) throws SQLException {
        Member m = new Member();
        m.setMemberId(rs.getInt("member_id"));
        m.setMemberNumber(rs.getString("member_number"));
        m.setFullName(rs.getString("full_name"));
        m.setEmail(rs.getString("email"));
        m.setUsername(rs.getString("username"));
        m.setPassword(rs.getString("password"));
        m.setRole(rs.getString("role"));
        return m;
    }
}
