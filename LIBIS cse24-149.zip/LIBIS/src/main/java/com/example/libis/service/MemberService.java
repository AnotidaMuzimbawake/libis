package com.example.libis.service;

import com.example.libis.dao.MemberDao;
import com.example.libis.dao.MemberDaoImpl;
import com.example.libis.exception.ValidationException;
import com.example.libis.model.Member;

import java.util.ArrayList;
import java.util.List;

public class MemberService {

    private final MemberDao memberDao = new MemberDaoImpl();

    public List<Member> list(String term) {
        if (term == null || term.trim().isEmpty()) {
            return memberDao.findAll();
        }
        return memberDao.search(term.trim());
    }

    public Member find(int memberId) {
        return memberDao.findById(memberId);
    }

    public void create(Member m) throws ValidationException {
        List<String> errors = validate(m, true);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
        memberDao.create(m);
    }

    public void update(Member m) throws ValidationException {
        Member existing = memberDao.findById(m.getMemberId());
        if (existing == null) {
            throw new ValidationException("That member no longer exists.");
        }
        List<String> errors = validate(m, false);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
        if (m.getPassword() == null || m.getPassword().isEmpty()) {
            m.setPassword(existing.getPassword());
        }
        memberDao.update(m);
    }

    public Member delete(int memberId, String signedInUsername) throws ValidationException {
        Member member = memberDao.findById(memberId);
        if (member == null) {
            throw new ValidationException("That member no longer exists.");
        }
        if (member.getUsername().equals(signedInUsername)) {
            throw new ValidationException("You cannot delete the account you are signed in with.");
        }
        memberDao.delete(memberId);
        return member;
    }

    private List<String> validate(Member m, boolean creating) {
        List<String> errors = new ArrayList<>();

        if (isBlank(m.getMemberNumber())) {
            errors.add("Member number is required.");
        }
        if (isBlank(m.getFullName())) {
            errors.add("Full name is required.");
        }
        if (isBlank(m.getEmail())) {
            errors.add("Email is required.");
        } else if (!m.getEmail().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            errors.add("Email address is not in a valid format.");
        }
        if (isBlank(m.getUsername())) {
            errors.add("Username is required.");
        }
        if (creating && isBlank(m.getPassword())) {
            errors.add("Password is required.");
        }
        if (!"member".equals(m.getRole()) && !"librarian".equals(m.getRole())) {
            errors.add("Role must be member or librarian.");
        }

        if (!isBlank(m.getMemberNumber())) {
            Member other = memberDao.findByMemberNumber(m.getMemberNumber());
            if (other != null && other.getMemberId() != m.getMemberId()) {
                errors.add("Member number " + m.getMemberNumber() + " is already used by another member.");
            }
        }
        if (!isBlank(m.getEmail())) {
            Member other = memberDao.findByEmail(m.getEmail());
            if (other != null && other.getMemberId() != m.getMemberId()) {
                errors.add("Email " + m.getEmail() + " is already used by another member.");
            }
        }
        if (!isBlank(m.getUsername())) {
            Member other = memberDao.findByUsername(m.getUsername());
            if (other != null && other.getMemberId() != m.getMemberId()) {
                errors.add("Username " + m.getUsername() + " is already used by another member.");
            }
        }
        return errors;
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}