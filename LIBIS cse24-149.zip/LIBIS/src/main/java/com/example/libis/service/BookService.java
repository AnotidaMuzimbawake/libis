package com.example.libis.service;

import com.example.libis.dao.BookDao;
import com.example.libis.dao.BookDaoImpl;
import com.example.libis.dao.LoanDao;
import com.example.libis.dao.LoanDaoImpl;
import com.example.libis.exception.ValidationException;
import com.example.libis.model.Book;

import java.time.Year;
import java.util.ArrayList;
import java.util.List;

public class BookService {

    private final BookDao bookDao = new BookDaoImpl();
    private final LoanDao loanDao = new LoanDaoImpl();

    public List<Book> list(String term) {
        if (term == null || term.trim().isEmpty()) {
            return bookDao.findAll();
        }
        return bookDao.search(term.trim());
    }

    public Book find(int bookId) {
        return bookDao.findById(bookId);
    }

    public void create(Book b, String yearText) throws ValidationException {
        List<String> errors = validate(b, yearText);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
        bookDao.create(b);
    }

    public void update(Book b, String yearText) throws ValidationException {
        if (bookDao.findById(b.getBookId()) == null) {
            throw new ValidationException("That book no longer exists.");
        }
        List<String> errors = validate(b, yearText);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
        bookDao.update(b);
    }

    public Book delete(int bookId) throws ValidationException {
        Book book = bookDao.findById(bookId);
        if (book == null) {
            throw new ValidationException("That book no longer exists.");
        }
        if (loanDao.hasOpenLoan(bookId)) {
            throw new ValidationException(book.getTitle() + " cannot be deleted because it is currently on loan.");
        }
        bookDao.delete(bookId);
        return book;
    }

    private List<String> validate(Book b, String yearText) {
        List<String> errors = new ArrayList<>();

        if (isBlank(b.getIsbn())) {
            errors.add("ISBN is required.");
        }
        if (isBlank(b.getTitle())) {
            errors.add("Title is required.");
        }
        if (isBlank(b.getAuthor())) {
            errors.add("Author is required.");
        }

        if (!isBlank(b.getIsbn())) {
            Book other = bookDao.findByIsbn(b.getIsbn());
            if (other != null && other.getBookId() != b.getBookId()) {
                errors.add("ISBN " + b.getIsbn() + " is already used by another book.");
            }
        }

        if (isBlank(yearText)) {
            errors.add("Published year is required.");
        } else {
            try {
                int year = Integer.parseInt(yearText.trim());
                if (year > Year.now().getValue()) {
                    errors.add("Published year cannot be in the future.");
                } else if (year < 1) {
                    errors.add("Published year must be a positive whole number.");
                } else {
                    b.setPublishedYear(year);
                }
            } catch (NumberFormatException e) {
                errors.add("Published year must be a whole number, for example 1994.");
            }
        }
        return errors;
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}