package com.example.libis.controller;

import com.example.libis.exception.DataAccessException;
import com.example.libis.exception.ValidationException;
import com.example.libis.model.Member;
import com.example.libis.service.MemberService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "memberAdminController", value = "/librarian/members")
public class MemberAdminController extends HttpServlet {

    private final MemberService memberService = new MemberService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        try {
            switch (action) {
                case "new" -> {
                    Member m = new Member();
                    m.setRole("member");
                    showForm(request, response, m, "create");
                }
                case "edit" -> {
                    Member m = memberService.find(Integer.parseInt(request.getParameter("id")));
                    if (m == null) {
                        request.getSession().setAttribute("adminError", "That member no longer exists.");
                        response.sendRedirect(request.getContextPath() + "/librarian/members");
                        return;
                    }
                    showForm(request, response, m, "update");
                }
                case "confirm" -> {
                    Member m = memberService.find(Integer.parseInt(request.getParameter("id")));
                    if (m == null) {
                        request.getSession().setAttribute("adminError", "That member no longer exists.");
                        response.sendRedirect(request.getContextPath() + "/librarian/members");
                        return;
                    }
                    request.setAttribute("member", m);
                    request.getRequestDispatcher("/WEB-INF/member-confirm.jsp").forward(request, response);
                }
                default -> {
                    String q = request.getParameter("q");
                    request.setAttribute("members", memberService.list(q));
                    request.setAttribute("searchTerm", q);
                    request.getRequestDispatcher("/WEB-INF/members.jsp").forward(request, response);
                }
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/librarian/members");
        } catch (DataAccessException e) {
            log("Member page failed", e);
            request.getSession().setAttribute("adminError", "A database error occurred. Please try again.");
            response.sendRedirect(request.getContextPath() + "/librarian/members");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        String back = request.getContextPath() + "/librarian/members";

        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("memberId"));
                Member deleted = memberService.delete(id, request.getRemoteUser());
                session.setAttribute("adminInfo", "Member " + deleted.getMemberNumber() + " ("
                        + deleted.getFullName() + ") and their borrowing history have been deleted.");
                response.sendRedirect(back);
                return;
            }

            Member m = readMember(request);
            try {
                if ("update".equals(action)) {
                    memberService.update(m);
                    session.setAttribute("adminInfo", "Member " + m.getMemberNumber() + " was updated.");
                } else {
                    memberService.create(m);
                    session.setAttribute("adminInfo", "Member " + m.getMemberNumber() + " was created.");
                }
                response.sendRedirect(back);
            } catch (ValidationException e) {
                request.setAttribute("errors", e.getErrors());
                showForm(request, response, m, "update".equals(action) ? "update" : "create");
            }
        } catch (ValidationException e) {
            session.setAttribute("adminError", e.getMessage());
            response.sendRedirect(back);
        } catch (NumberFormatException e) {
            response.sendRedirect(back);
        } catch (DataAccessException e) {
            log("Member action failed", e);
            session.setAttribute("adminError", "A database error occurred. Please try again.");
            response.sendRedirect(back);
        }
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Member m, String formAction)
            throws ServletException, IOException {
        request.setAttribute("member", m);
        request.setAttribute("formAction", formAction);
        request.getRequestDispatcher("/WEB-INF/member-form.jsp").forward(request, response);
    }

    private Member readMember(HttpServletRequest request) {
        Member m = new Member();
        String id = request.getParameter("memberId");
        if (id != null && !id.isEmpty()) {
            m.setMemberId(Integer.parseInt(id));
        }
        m.setMemberNumber(trim(request.getParameter("memberNumber")));
        m.setFullName(trim(request.getParameter("fullName")));
        m.setEmail(trim(request.getParameter("email")));
        m.setUsername(trim(request.getParameter("username")));
        m.setPassword(request.getParameter("password"));
        m.setRole(request.getParameter("role"));
        return m;
    }

    private String trim(String s) {
        return s == null ? null : s.trim();
    }
}