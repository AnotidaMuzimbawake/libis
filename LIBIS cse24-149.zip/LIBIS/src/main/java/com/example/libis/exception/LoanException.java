package com.example.libis.exception;

public class LoanException extends Exception {

    private final String messageKey;

    public LoanException(String messageKey) {
        super(messageKey);
        this.messageKey = messageKey;
    }

    public String getMessageKey() {
        return messageKey;
    }
}