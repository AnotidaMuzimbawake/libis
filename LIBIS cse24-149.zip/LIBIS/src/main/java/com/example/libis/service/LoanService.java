package com.example.libis.service;

import com.example.libis.dao.BookDao;
import com.example.libis.dao.BookDaoImpl;
import com.example.libis.dao.LoanDao;
import com.example.libis.dao.LoanDaoImpl;
import com.example.libis.exception.LoanException;
import com.example.libis.model.Book;
import com.example.libis.model.Loan;

import java.time.LocalDate;
import java.util.List;

public class LoanService {

    public static final int MAX_LOANS = 3;

    private final LoanDao loanDao = new LoanDaoImpl();
    private final BookDao bookDao = new BookDaoImpl();

    public void borrow(int memberId, int bookId) throws LoanException {
        Book book = bookDao.findById(bookId);
        if (book == null) {
            throw new LoanException("error.book.notfound");
        }
        if (loanDao.hasOpenLoan(bookId)) {
            throw new LoanException("error.book.onloan");
        }
        if (loanDao.countOpenByMember(memberId) >= MAX_LOANS) {
            throw new LoanException("error.loan.limit");
        }
        loanDao.create(memberId, bookId, LocalDate.now());
    }

    public void giveBack(int memberId, int bookId) throws LoanException {
        boolean returned = loanDao.markReturned(memberId, bookId, LocalDate.now());
        if (!returned) {
            throw new LoanException("error.loan.notheld");
        }
    }

    public List<Loan> openLoans(int memberId) {
        return loanDao.findOpenByMember(memberId);
    }

    public List<Loan> history(int memberId) {
        return loanDao.findHistoryByMember(memberId);
    }
}