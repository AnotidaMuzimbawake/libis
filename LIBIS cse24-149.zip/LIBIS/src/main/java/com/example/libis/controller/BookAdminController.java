package com.example.libis.controller;

import com.example.libis.exception.DataAccessException;
import com.example.libis.exception.ValidationException;
import com.example.libis.model.Book;
import com.example.libis.service.BookService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "bookAdminController", value = "/librarian/books")
public class BookAdminController extends HttpServlet {

    private final BookService bookService = new BookService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        try {
            switch (action) {
                case "new" -> showForm(request, response, new Book(), "", "create");
                case "edit" -> {
                    Book b = bookService.find(Integer.parseInt(request.getParameter("id")));
                    if (b == null) {
                        request.getSession().setAttribute("adminError", "That book no longer exists.");
                        response.sendRedirect(request.getContextPath() + "/librarian/books");
                        return;
                    }
                    showForm(request, response, b, String.valueOf(b.getPublishedYear()), "update");
                }
                case "confirm" -> {
                    Book b = bookService.find(Integer.parseInt(request.getParameter("id")));
                    if (b == null) {
                        request.getSession().setAttribute("adminError", "That book no longer exists.");
                        response.sendRedirect(request.getContextPath() + "/librarian/books");
                        return;
                    }
                    request.setAttribute("book", b);
                    request.getRequestDispatcher("/WEB-INF/book-confirm.jsp").forward(request, response);
                }
                default -> {
                    String q = request.getParameter("q");
                    request.setAttribute("books", bookService.list(q));
                    request.setAttribute("searchTerm", q);
                    request.getRequestDispatcher("/WEB-INF/books.jsp").forward(request, response);
                }
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/librarian/books");
        } catch (DataAccessException e) {
            log("Book page failed", e);
            request.getSession().setAttribute("adminError", "A database error occurred. Please try again.");
            response.sendRedirect(request.getContextPath() + "/librarian/books");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        String back = request.getContextPath() + "/librarian/books";

        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("bookId"));
                Book deleted = bookService.delete(id);
                session.setAttribute("adminInfo", "Book \"" + deleted.getTitle() + "\" was deleted.");
                response.sendRedirect(back);
                return;
            }

            Book b = readBook(request);
            String yearText = request.getParameter("publishedYear");
            try {
                if ("update".equals(action)) {
                    bookService.update(b, yearText);
                    session.setAttribute("adminInfo", "Book \"" + b.getTitle() + "\" was updated.");
                } else {
                    bookService.create(b, yearText);
                    session.setAttribute("adminInfo", "Book \"" + b.getTitle() + "\" was created.");
                }
                response.sendRedirect(back);
            } catch (ValidationException e) {
                request.setAttribute("errors", e.getErrors());
                showForm(request, response, b, yearText, "update".equals(action) ? "update" : "create");
            }
        } catch (ValidationException e) {
            session.setAttribute("adminError", e.getMessage());
            response.sendRedirect(back);
        } catch (NumberFormatException e) {
            response.sendRedirect(back);
        } catch (DataAccessException e) {
            log("Book action failed", e);
            session.setAttribute("adminError", "A database error occurred. Please try again.");
            response.sendRedirect(back);
        }
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response,
                          Book b, String yearText, String formAction)
            throws ServletException, IOException {
        request.setAttribute("book", b);
        request.setAttribute("yearText", yearText);
        request.setAttribute("formAction", formAction);
        request.getRequestDispatcher("/WEB-INF/book-form.jsp").forward(request, response);
    }

    private Book readBook(HttpServletRequest request) {
        Book b = new Book();
        String id = request.getParameter("bookId");
        if (id != null && !id.isEmpty()) {
            b.setBookId(Integer.parseInt(id));
        }
        b.setIsbn(trim(request.getParameter("isbn")));
        b.setTitle(trim(request.getParameter("title")));
        b.setAuthor(trim(request.getParameter("author")));
        b.setGenre(trim(request.getParameter("genre")));
        b.setSynopsis(trim(request.getParameter("synopsis")));
        return b;
    }

    private String trim(String s) {
        return s == null ? null : s.trim();
    }
}