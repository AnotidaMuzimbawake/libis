package com.example.libis.dao;

import com.example.libis.model.Book;

import java.util.List;

public interface BookDao {
    List<Book> findAll();
    Book findById(int bookId);
    List<Book> search(String term);
    Book findByIsbn(String isbn);
    void create(Book book);
    void update(Book book);
    void delete(int bookId);
}