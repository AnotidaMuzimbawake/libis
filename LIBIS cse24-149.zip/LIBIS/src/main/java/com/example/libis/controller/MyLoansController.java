package com.example.libis.controller;

import com.example.libis.dao.MemberDao;
import com.example.libis.dao.MemberDaoImpl;
import com.example.libis.exception.DataAccessException;
import com.example.libis.model.Member;
import com.example.libis.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "myLoansController", value = "/my-loans")
public class MyLoansController extends HttpServlet {

    private final LoanService loanService = new LoanService();
    private final MemberDao memberDao = new MemberDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Member member = memberDao.findByUsername(request.getRemoteUser());
            request.setAttribute("openLoans", loanService.openLoans(member.getMemberId()));
            request.setAttribute("history", loanService.history(member.getMemberId()));
        } catch (DataAccessException e) {
            log("My loans failed", e);
            request.getSession().setAttribute("flashError", "error.database");
        }
        request.getRequestDispatcher("/WEB-INF/my-loans.jsp").forward(request, response);
    }
}