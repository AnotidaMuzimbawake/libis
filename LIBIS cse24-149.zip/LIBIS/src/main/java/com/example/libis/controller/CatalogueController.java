package com.example.libis.controller;

import com.example.libis.dao.BookDao;
import com.example.libis.dao.BookDaoImpl;
import com.example.libis.exception.DataAccessException;
import com.example.libis.model.Book;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@WebServlet(name = "catalogueController", value = "/catalogue")
public class CatalogueController extends HttpServlet {

    private final BookDao bookDao = new BookDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String searchTerm = request.getParameter("q");

        List<Book> results;

        try {
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                results = bookDao.findAll();
            } else {
                results = bookDao.search(searchTerm.trim());
            }
        } catch (DataAccessException e) {
            log("Catalogue query failed", e);
            results = new ArrayList<>();
            request.setAttribute("error", "The catalogue is unavailable right now. Please try again.");
        }

        request.setAttribute("books", results);
        request.setAttribute("searchTerm", searchTerm);

        request.getRequestDispatcher("/WEB-INF/welcome.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doGet(request, response);
    }
}