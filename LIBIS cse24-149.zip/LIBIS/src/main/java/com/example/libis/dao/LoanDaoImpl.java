package com.example.libis.dao;

import com.example.libis.model.Loan;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class LoanDaoImpl implements LoanDao {

    private static final String BASE =
            "SELECT l.loan_id, l.member_id, l.book_id, b.title AS book_title, "
                    + "l.borrowed_on, l.returned_on "
                    + "FROM loans l JOIN books b ON b.book_id = l.book_id ";

    @Override
    public void create(int memberId, int bookId, LocalDate borrowedOn) {
        Jdbc.update("INSERT INTO loans (member_id, book_id, borrowed_on) VALUES (?, ?, ?)",
                ps -> {
                    ps.setInt(1, memberId);
                    ps.setInt(2, bookId);
                    ps.setDate(3, Date.valueOf(borrowedOn));
                });
    }

    // A return sets returned_on. The row is NOT deleted: it becomes borrowing history.
    @Override
    public boolean markReturned(int memberId, int bookId, LocalDate returnedOn) {
        int rows = Jdbc.update("UPDATE loans SET returned_on = ? "
                        + "WHERE member_id = ? AND book_id = ? AND returned_on IS NULL",
                ps -> {
                    ps.setDate(1, Date.valueOf(returnedOn));
                    ps.setInt(2, memberId);
                    ps.setInt(3, bookId);
                });
        return rows > 0;
    }

    @Override
    public int countOpenByMember(int memberId) {
        return Jdbc.count("SELECT COUNT(*) FROM loans WHERE member_id = ? AND returned_on IS NULL",
                ps -> ps.setInt(1, memberId));
    }

    @Override
    public List<Loan> findOpenByMember(int memberId) {
        return Jdbc.queryList(BASE + "WHERE l.member_id = ? AND l.returned_on IS NULL ORDER BY l.borrowed_on DESC",
                ps -> ps.setInt(1, memberId), LoanDaoImpl::map);
    }

    @Override
    public List<Loan> findHistoryByMember(int memberId) {
        return Jdbc.queryList(BASE + "WHERE l.member_id = ? AND l.returned_on IS NOT NULL ORDER BY l.returned_on DESC",
                ps -> ps.setInt(1, memberId), LoanDaoImpl::map);
    }

    @Override
    public boolean hasOpenLoan(int bookId) {
        return Jdbc.count("SELECT COUNT(*) FROM loans WHERE book_id = ? AND returned_on IS NULL",
                ps -> ps.setInt(1, bookId)) > 0;
    }

    private static Loan map(ResultSet rs) throws SQLException {
        Loan loan = new Loan();
        loan.setLoanId(rs.getInt("loan_id"));
        loan.setMemberId(rs.getInt("member_id"));
        loan.setBookId(rs.getInt("book_id"));
        loan.setBookTitle(rs.getString("book_title"));
        loan.setBorrowedOn(rs.getDate("borrowed_on").toLocalDate());
        Date returned = rs.getDate("returned_on");
        loan.setReturnedOn(returned == null ? null : returned.toLocalDate());
        return loan;
    }
}